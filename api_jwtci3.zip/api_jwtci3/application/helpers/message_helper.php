<?php
 
 function done(){

	return "Added Successfully";
 }

 function amounts($data,$message){

	return $message.':'.($data+1000);
 }