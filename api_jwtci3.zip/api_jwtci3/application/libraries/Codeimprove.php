<?php 

class Codeimprove {
  
	public function getresponse()
	{     
		return 'Yes i am available';
	}


	public function dataprint($no)
	{     
		return 'Yes dataprint function called--'.$no;
	}
 
}
